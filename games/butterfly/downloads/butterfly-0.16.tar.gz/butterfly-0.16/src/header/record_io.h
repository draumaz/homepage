int * record_reader();
void record_writer(int line);
void record_generate();
void record_exists();