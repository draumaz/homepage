void scr_sleep(int ms);
void scr_popwrite(char* l, int p);