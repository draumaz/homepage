void screen_up();
void screen_down();
void joystick();