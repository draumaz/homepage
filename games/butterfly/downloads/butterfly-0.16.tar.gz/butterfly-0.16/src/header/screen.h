void board_header(int x, int y);
void board_header_update(int x, int y, int m);
int entity_alive(int kind);
void scr_poison(int x, int y);
void scr_result(int x, int y);
void scr_board();
void scr_landing();