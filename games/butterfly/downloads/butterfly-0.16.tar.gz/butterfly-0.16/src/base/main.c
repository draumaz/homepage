#include "./../header/joystick.h"

int main() { 
	joystick();
	return 0;
}
